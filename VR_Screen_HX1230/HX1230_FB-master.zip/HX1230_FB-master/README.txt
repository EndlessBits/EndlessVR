This is fast 9-bit SPI library for HX1230 96x68 display.

Supports only hardware 9-bit SPI
Uses 96*9 bytes of RAM as frame buffer memory, most common graphics primitives implemented with dithering
Some examples require PropFonts library
